package com.example.crosstheroad;
import android.graphics.Bitmap;

//Road Class that is an entity whose length and height as well as x and y positions can be set.
public class Road extends Entity {
    public Road(int x, int y, int w, int h, Bitmap bm) {
        super(x, y, w, h, bm);
    }
}




